<div class="small-gap"></div>
<div class="only-375"></div>
<div class="small-gap hidden-large"></div>
<center >
    <h1 class="h2 ">At <i>Erfolg</i>,
    your business is our
    passion.</h1>		
    <br>		 
    
    <button id="js-ripple-btn" class="button styl-material" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false">     
        <span class="lets">Request case study</span>
        <svg class="ripple-obj">
            <use height="100" width="100" xlink:href="#ripply-scott" class="js-ripple"></use>
        </svg>
    </button>	 
</center>
<div class="tiny-gap"></div>
<div class="container">
    <div class="col-md-8 col-md-offset-2">
        <h1 class="h2  text-center">Leave us a message</h1>     
        <h4 class="text-center">You can find us literally anywhere, just push a button and we’re there</h4>
        <div class="small-gap"></div>
        
        <center>
            <ul class="footer">                            
                <li><a href="https://www.facebook.com/ErfolgCreatingSuccess/"><i class="fa fa-facebook " aria-hidden="true"></i></a></li>
                <li><i class="fa fa-twitter" aria-hidden="true"></i></li>
                <li><i class="fa fa-linkedin " aria-hidden="true"></i></li>   
                <!--<li><a href="contact.php"><i class="fa fa-phone " aria-hidden="true"></i></a></li>-->                      
            </ul>
        </center>
    </div>
</div>

<h2 class="small-footer"></h2>